# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ #
# ~~~ PROMIS Example (GaPM-CDM & aPM-CDM) ~~~ #
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ #

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~ #
# ~~~ CV analysis (80/20) ~~~ #
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~ #

rm(list = ls())

library(dplyr)
library(ggplot2)
library(latex2exp)
library(tidyr)
library(tibble)

res <- NULL
for(i in 1:100){ # Number of replications
    for(j in 1:7){ # Number of latent variables
        res <- rbind(res,readRDS(paste0("PROMIS/CV/sim",i,"_K",j,"_PROMIS.rds")))
    }
}

colnames(res) <- c("sim","K","ga_train","ga_test","ad_train","ad_test")
res <- as.data.frame(res)
res <- res |>  tidyr::drop_na()
res$diff = res$ga_test - res$ad_test

df_res1 <- res |> na.omit() |>
    dplyr::group_by(K) |>
    dplyr::summarise_at(dplyr::vars(ga_test),
                        list(mean = mean, sd = function(x){sd(x)/10})) # 10 = sqrt(100), number of replications
df_res1$mod = "GaPM-CDM"

df_res2 <- res |> na.omit() |>
    dplyr::group_by(K) |>
    dplyr::summarise_at(dplyr::vars(ad_test),
                        list(mean = mean, sd = function(x){sd(x)/10}))
df_res2$mod = "aPM-CDM"

df_res <- rbind(df_res2,df_res1)
df_res$mod <- factor(df_res$mod, levels = c("GaPM-CDM", "aPM-CDM"))

# Figure 3: Cross-validation test-data marginal log-likelihood for the GaPM-CDM (solid line)
# and aPM-CDM (dashed line). Error bars correspond to the standard error of the average
# test-data marginal log-likelihood for each level of K = 1,...,7

ggplot(df_res, aes(x=K, y=mean, color = mod, shape = mod)) +
    geom_errorbar(aes(ymin=(mean-sd), ymax=(mean+sd)), width=0.2) +
    geom_point(size=2.5) +
    geom_line(aes(linetype = mod)) +
    scale_color_manual(values = c("GaPM-CDM" = "gray20", "aPM-CDM" = "gray20"),
                       name = "\nModel\n") +
    scale_shape_manual(values = c("GaPM-CDM" = 16, "aPM-CDM" = 17),
                       name = "\nModel\n") +
    scale_linetype_manual(values = c("GaPM-CDM" = "solid", "aPM-CDM" = "dashed"),
                          name = "\nModel\n") +
    scale_x_continuous(breaks = 1:7) +
    theme_classic() +
    theme(plot.title = element_text(margin = margin(t = 0, r = 0, b = 10, l = 0),
                                    size = 15),
          plot.subtitle = element_text(size = 13),
          axis.title.y = element_text(margin = margin(t = 0, r = 15, b = 0, l = 0),
                                      size = 13),
          axis.title.x = element_text(margin = margin(t = 17, r = 0, b = 0, l = 0),
                                      size = 13),
          axis.title =   element_text(margin = margin(t = 0, r = 0, b = 10, l = 0)),
          axis.text.x = element_text(size = 12),
          axis.text.y = element_text(size = 12),
          plot.margin = margin(t = 5, r = 5, b = 0, l = 5)) +
    ylab(TeX(r"(Test data marginal log-likelihoods)")) +
    xlab(TeX(r"(Latent space dimension ($K$))")) # Save 600 x 375

# ~~~~~~~~~~~~~~~~~~~~~~~~~~ #
# ~~~ Full data analysis ~~~ #
# ~~~~~~~~~~~~~~~~~~~~~~~~~~ #

rm(list = ls())

library(pmCDM)
library(dplyr)
library(ggplot2)
library(latex2exp)
library(tidyr)
library(tibble)

data = as.matrix(PROMIS[,-1])
K = 5

# ~~~~~~~~~~~~~~~ #
# ~~ ATTENTION ~~ #
# ~~~~~~~~~~~~~~~ #
# Code below can take several minutes to run (anywhere between 15 min to 45 min), depending on the machine.

assign(paste0("mod_ga_K", K),
       pmCDM::gapmCDM(
           data = data, q = K, h = .1,
           knots = seq(.05,.95,by=.05),
           tune.lim = 10, iter.lim = 9e4, burn.in = 4.5e4,
           stop.atconv = F,
           verbose = T, verbose.every = 5e1,
           sampler = "MALA",
           start.zn = "fa",
           return.trace = T, nsim = 2e4, seed = K))

assign(paste0("mod_ad_K", K),
       pmCDM::apmCDM(
           data = data, q = K, h = .1,
           gamma = .3, gamma.R = ifelse(K < 5, .65, .35),
           tune.lim = 10, iter.lim = 9e4, burn.in = 4.5e4,
           stop.atconv = F,
           verbose = T, verbose.every = 5e1,
           sampler = "MALA",
           start.zn = "fa", cor.R = F,
           return.trace = T, nsim = 2e4, seed = K))

# Figures and tables.

roworder5 = c("SRPPER20", "SRPPER38", "SRPPER52", "SRPPER50", "SRPPER46", "SRPPER32",
              "SRPPER35", "SRPPER39", "SRPPER45", "SRPPER36", "SRPPER49", "SRPPER48",
              "SRPPER54", "SRPPER34", "SRPPER04", "SRPPER12", "SRPPER11", "SRPPER21",
              "SRPPER25", "SRPPER40", "SRPPER13", "SRPPER28", "SRPPER03", "SRPPER15",
              "SRPPER29", "SRPPER27", "SRPPER41", "SRPPER55", "SRPPER42", "SRPPER43",
              "SRPPER56", "SRPPER17", "SRPPER30", "SRPPER14", "SRPPER01", "SRPPER31",
              "SRPPER16", "SRPPER37", "SRPPER26", "SRPPER47", "SRPPER09", "SRPPER06",
              "SRPPER19", "SRPPER02", "SRPPER44", "SRPPER23", "SRPPER10", "SRPPER05",
              "SRPPER07", "SRPPER24", "SRPPER22", "SRPPER18", "SRPPER08", "SRPPER51",
              "SRPPER53", "SRPPER33")

# GaPM-CDM results:
# ~~~~~~~~~~~~~~~~

tmp_Ahat <- mod_ga_K5$A[roworder5,c(1,4,5,2,3)] |>
    as.data.frame() |>
    rename(U1 = Z1, U2 = Z4, U3 = Z5, U4 = Z2, U5 = Z3) |>
    rownames_to_column("item") |>
    pivot_longer(-c(item), names_to = "attribute", values_to = "value") |>
    mutate(attribute = factor(attribute,
                              levels= rev(paste0("U",1:ncol(mod_ga_K5$A))))) |>
    mutate(item = factor(item,
                         levels=(roworder5)))

plot_Ahat <- ggplot(tmp_Ahat, aes(y=attribute, x=item, fill=value)) +
    geom_tile() +
    scale_fill_gradient(low = "white", high = "black",limits = c(0,1),
                        name = "Estim.\nweight\nvalue\n",
                        guide = guide_colorbar(barwidth = 0.5, barheight = 10,
                                               title.position = "top",
                                               theme = theme(legend.text.position = "right"))) +
    theme_classic() +
    theme(plot.title = element_text(margin = margin(t = 0, r = 0, b = 5, l = 0), size = 16),
          plot.subtitle = element_text(size = 14, margin = margin(t = 0, r = 0, b = 10, l = 0)),
          axis.title.y = element_text(margin = margin(t = 0, r = 15, b = 0, l = 0), size = 13),
          axis.title.x = element_text(margin = margin(t = 17, r = 0, b = 0, l = 0), size = 13),
          axis.title =   element_text(margin = margin(t = 0, r = 0, b = 10, l = 0)),
          axis.text.x = element_text(size = 8, angle=90, vjust=.5, hjust=1),
          axis.text.y = element_text(size = 12),
          plot.margin = margin(t = 10, r = 2, b = 5, l = 2)) +
    xlab(TeX(r"(Item)")) +
    ylab(TeX(r"(Latent attribute ($U$))")) # save H(430) W(780)

# Figure 4: Matrix of estimated weights (transposed) for the K = 5 dimensional GaPM-CDM on the PROMIS dataset.
plot_Ahat

# Table 5: Estimated correlation matrix for the five recovered latent attributes. PROMIS dataset
round(mod_ga_K5$R[c(1,4,5,2,3),c(1,4,5,2,3)],3) |> xtable::xtable()

# aPM-CDM results:
# ~~~~~~~~~~~~~~~~

tmp_Ghat <-
    mod_ad_K5$G[roworder5,c(1,2,5,6,3,4)] |>
    as.data.frame() |>
    rename(U1 = Z1, U2 = Z4, U3 = Z5, U4 = Z2, U5 = Z3) |>
    rownames_to_column("item") |>
    pivot_longer(-c(item), names_to = "attribute", values_to = "value") |>
    mutate(attribute = factor(attribute,
                              levels= c(rev(paste0("U",1:ncol(mod_ad_K5$G[,-1]))), "(Intercept)"))) |>
    mutate(item = factor(item,
                         levels=(roworder5)))

plot_Ghat <- ggplot(tmp_Ghat, aes(y=attribute, x=item, fill=value)) +
    geom_tile() +
    scale_fill_gradient(low = "white", high = "black",
                        name = "Estim.\nweight\nvalue\n", limits = c(0,1),
                        guide = guide_colorbar(barwidth = 0.5, barheight = 10,
                                               title.position = "top",
                                               theme = theme(legend.text.position = "right"))) +
    theme_classic() +
    theme(plot.title = element_text(margin = margin(t = 0, r = 0, b = 5, l = 0),
                                    size = 16),
          plot.subtitle = element_text(size = 14,
                                       margin = margin(t = 0, r = 0, b = 10, l = 0)),
          axis.title.y = element_text(margin = margin(t = 0, r = 15, b = 0, l = 0),
                                      size = 13),
          axis.title.x = element_text(margin = margin(t = 17, r = 0, b = 0, l = 0),
                                      size = 13),
          axis.title =   element_text(margin = margin(t = 0, r = 0, b = 10, l = 0)),
          axis.text.x = element_text(size = 8, angle=90, vjust=.5, hjust=1),
          axis.text.y = element_text(size = 12),
          plot.margin = margin(t = 10, r = 2, b = 5, l = 2)) +
    xlab(TeX(r"(Item)")) +
    ylab(TeX(r"(Latent attribute ($U$))")) # save H(430) W(780)

# Figure A4 (Supp. Materials): Matrix of estimated factor loadings (transposed) for the K = 5 dimensional aPM-CDM on the PROMIS dataset.
plot_Ghat
