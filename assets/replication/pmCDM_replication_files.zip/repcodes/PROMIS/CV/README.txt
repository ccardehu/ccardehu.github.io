
README (10/07/2026)

Files in PROMIS/CV correspond to different simulation results (simXX, 
with XX from 1 to 100), for different values of the latent space dimension
(KXX, with XX from 1 to 7).
