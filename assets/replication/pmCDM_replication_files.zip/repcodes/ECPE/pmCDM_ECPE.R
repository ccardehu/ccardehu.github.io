# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ #
# ~~~ ECPE Example (GaPM-CDM & aPM-CDM) ~~~ #
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ #

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ---- Full data analysis ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~

rm(list = ls())

library(tidyverse)
library(dplyr)
library(ggplot2)
library(gridExtra)
library(latex2exp)

data = as.matrix(GDINA::realdata_ECPE$dat)
Qmatrix = as.matrix(GDINA::realdata_ECPE$Q)
K = ncol(Qmatrix)

ACDM2G <- function(x,Qmatrix){
    G = cbind(1,Qmatrix)
    for(i in 1:nrow(Qmatrix)){  G[i,G[i,] != 0] = unlist(unname(x[names(x)[i]])) }
    return(G)
}

# ~~~~~~~~~~~~~~~ #
# ~~ ATTENTION ~~ #
# ~~~~~~~~~~~~~~~ #
# Code below can take several minutes to run (anywhere between 20 min to 45 min), depending on the machine.

mod_GDINA <- GDINA::GDINA(
    dat = data, Q = Qmatrix, model = "GDINA",
    verbose = 1,
    mono.constraint = T)

mod_ACDM <- GDINA::GDINA(
    dat = data, Q = Qmatrix, model = "ACDM",
    verbose = 1)

mod_aPMCDM <- pmCDM::apmCDM(
    data = data, q = K, h = .1,
    Qmatrix = Qmatrix,
    sampler = "MALA",
    tune.lim = 10, iter.lim = 9e4, burn.in = 4.5e4,
    verbose = T, return.trace = T,
    stop.atconv = F,
    verbose.every = 5e1, nsim = 2e4, seed = 1234)

mod_GaPMCDM <- pmCDM::gapmCDM(
    data = data, q = K, h = .1,
    Qmatrix = Qmatrix,
    sampler = "MALA",
    knots = c(.025, .05,seq(.1,.9,by = .1),.95, .975),
    tune.lim = 10, iter.lim = 9e4, burn.in = 4.5e4,
    verbose = T, return.trace = T,
    stop.atconv = F,
    verbose.every = 5e1, nsim = 2e4, seed = 1234)

# Table 4: Estimated covariance (for aPM-CDM) and correlation (for GaPM-CDM) matrices for the latent attributes. ECPE dataset.
round(mod_aPMCDM$R,3) |> xtable::xtable()
round(cov2cor(mod_aPMCDM$R),3)  |>  xtable::xtable()
round(mod_aPMCDM$mu,2); round(pnorm(mod_aPMCDM$mu),2)
round(mod_GaPMCDM$R,3) |>  xtable::xtable()
round(diag(cor(mod_GaPMCDM$U,mod_aPMCDM$U, method = "spear")),3)

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ---- Plots for conditional probability ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

df_agg <- function(mod, item, ord = NULL, knots = seq(.1,.9,by = 0.1), basis = "pwl"){
    U <- pnorm(seq(-5,5,by = 0.1))
    if("gapmCDM" %in% class(mod)){
        if(is.null(ord)) ord = 1:ncol(mod$R)
        A <- mod$A[,ord]
        out <- matrix(NA,length(U), ncol(A))
        for(i in 1:ncol(A)){
            if(basis == "pwl"){
                out[,i] <- as.matrix(splines2::bsp(U, knots = knots, degree = 1, Boundary.knots = c(0,1),
                                                   intercept = F))%*%mod$C[item,,ord[i], drop = F]
                out[,i] <- ifelse(out[,i] * A[item,i] > .Machine$double.eps, out[,i], 0)
            } else {
                out[,i] <- as.matrix(splines2::isp(U, knots = knots, degree = 2, Boundary.knots = c(0,1),
                                                   intercept = F))%*%mod$C[item,,ord[i], drop = F]
                out[,i] <- ifelse(out[,i] * A[item,i] > .Machine$double.eps, out[,i], 0)
            }
        }
        out <- as.data.frame(out)
        names(out) <- c("Morph.","Cohes.","Lexic.")
        out$U <- U
        out <- out %>%
            pivot_longer(cols = !U, names_to = "attribute",values_to = "Prob") %>%
            mutate(attribute = factor(attribute, levels=c("Morph.", "Cohes.", "Lexic.")))
        out$Item <- factor(paste0("Item ",item))
        out$mod <- factor("GaPM-CDM")
        out <- out %>%  mutate(Prob = replace(Prob, Prob ==0, NA))
        return(out)
    }

    if("apmCDM" %in% class(mod)){
        if(is.null(ord)) ord = 1:ncol(mod$R)
        G <- mod$G[,c(1,ord+1)]
        out <- matrix(NA,length(U), ncol(G)-1)
        # out[,1] <- G[item,1]
        for(i in 1:ncol(out)){
            out[,i] <- ifelse(U * G[item,i+1] != 0, U * G[item,i+1] + G[item,1], 0)
        }
        out <- as.data.frame(out)
        # names(out) <- c("Guess","Morph.","Cohes.","Lexic.")
        names(out) <- c("Morph.","Cohes.","Lexic.")
        out$U <- U
        out <- out %>%
            pivot_longer(cols = !U, names_to = "attribute", values_to = "Prob") %>%
            mutate(attribute = factor(attribute, levels=c("Morph.", "Cohes.", "Lexic.")))
        # mutate(attribute = factor(attribute, levels=c("Morph.", "Cohes.", "Lexic.","Guess")))
        out$Item <- factor(paste0("Item ",item))
        out$mod <- factor("PM-ACDM")
        out <- out %>%  mutate(Prob = replace(Prob, Prob ==0, NA))
        return(out)
    }
}

plot_pmCDM <- function(item,mod,knots = seq(.1,.9,by = 0.1), basis = "pwl"){

    df_item <- df_agg(mod = mod, item = item, knots = knots, basis = basis)

    if("gapmCDM" %in% class(mod)){
        df_text <- tibble(U = .75, Prob = .1,
                          Item = paste0("Item ",item),
                          attribute = c("Morph.", "Cohes.", "Lexic.")) %>%
            mutate(z = c(
                paste0(r"($\hat{\alpha}_{jk} = $)", round(mod$A[item,1],2)),
                paste0(r"($\hat{\alpha}_{jk} = $)", round(mod$A[item,2],2)),
                paste0(r"($\hat{\alpha}_{jk} = $)", round(mod$A[item,3],2))
            ))
        yla <- paste0(r"($\hat{g}_{jk}(U_k)$)")
    }
    if("apmCDM" %in% class(mod)){
        df_text <- tibble(U = .75, Prob = .1,
                          Item = paste0("Item ",item),
                          attribute = c("Morph.", "Cohes.", "Lexic.")) %>%
            mutate(z = c(
                paste0(r"($\hat{\delta}_{jk} = $)", round(mod$G[item,2],2)),
                paste0(r"($\hat{\delta}_{jk} = $)", round(mod$G[item,3],2)),
                paste0(r"($\hat{\delta}_{jk} = $)", round(mod$G[item,4],2))
            ))
        yla <- paste0(r"($\hat{\delta}_{jk} \cdot U_k$)")
    }

    gf_item <-
        ggplot(df_item, aes(x=U, y = Prob)) +
        geom_line(linewidth = 1, color = "black", na.rm = T) +
        facet_grid(. ~ factor(attribute, levels=c("Morph.", "Cohes.", "Lexic."))) +
        theme_bw() +
        scale_x_continuous(breaks=c(0, .5, 1), limits = c(0,1)) +
        scale_y_continuous(breaks=c(0, .5, 1), limits = c(0,1)) +
        theme(plot.title = element_text(margin = margin(t = 0, r = 0, b = 5, l = 0), size = 15),
              plot.subtitle = element_text(margin = margin(t = 0, r = 0, b = 10, l = 0), size = 13),
              axis.title.y = element_text(margin = margin(t = 0, r = 12, b = 0, l = 0), size = 13),
              axis.title.x = element_text(margin = margin(t = 12, r = 0, b = 0, l = 0), size = 13),
              axis.title =   element_text(margin = margin(t = 0, r = 0, b = 10, l = 0)),
              axis.text.x = element_text(size = 11),
              axis.text.y = element_text(size = 11),
              plot.margin = margin(t = 18, r = 5, b = 8, l = 2),
              panel.spacing = unit(1, "lines"),
              strip.background = element_rect(fill="white")) +
        ylab(TeX(yla)) +
        xlab(TeX(r"(Latent attribute level ($U$))")) +
        geom_text(data = df_text,
                  aes(x = U, y = Prob, label = TeX(z, output = "character")),
                  inherit.aes = FALSE, parse = TRUE, size = 12/.pt)

    outfun <- function(x,y,item,mod,knots = seq(.1,.9,by = 0.1), basis){
        if("gapmCDM" %in% class(mod)){
            A <- mod$A
            not0 = which(A[item,] > .Machine$double.eps)
            if(length(x) != length(y)) stop("Check lenght of U input")
            if(length(not0) > 2) stop("Check lenght of not0")
            out = vector(mode = "numeric", length = length(x))
            for(n in 1:length(x)){
                if(basis == "pwl"){
                    tmp1 <- as.matrix(splines2::bsp(x[n], knots = knots, degree = 1, Boundary.knots = c(0,1),
                                                    intercept = F))%*%mod$C[item,,not0[1], drop = F] * A[item,not0[1]]
                    tmp2 <- as.matrix(splines2::bsp(y[n], knots = knots, degree = 1, Boundary.knots = c(0,1),
                                                    intercept = F))%*%mod$C[item,,not0[2], drop = F] * A[item,not0[2]]
                    out[n] = c(tmp1) + c(tmp2)
                } else {
                    tmp1 <- as.matrix(splines2::isp(x[n], knots = knots, degree = 2, Boundary.knots = c(0,1),
                                                    intercept = F))%*%mod$C[item,,not0[1], drop = F] * A[item,not0[1]]
                    tmp2 <- as.matrix(splines2::isp(y[n], knots = knots, degree = 2, Boundary.knots = c(0,1),
                                                    intercept = F))%*%mod$C[item,,not0[2], drop = F] * A[item,not0[2]]
                    out[n] = c(tmp1) + c(tmp2)
                }
            }
            return(out)
        }

        if("apmCDM" %in% class(mod)){
            G <- mod$G
            not0 = which(G[item,-1] > .Machine$double.eps)+1
            if(length(x) != length(y)) stop("Check lenght of U input")
            if(length(not0) > 2) stop("Check lenght of not0")
            out = G[item,1] + x*G[item,not0[1]] + y*G[item,not0[2]]
            return(out)
        }
    }

    flag2D <- df_item %>% filter(!is.na(Prob)) %>% distinct(attribute) %>% unlist() %>% as.character()

    if(length(flag2D) > 1){

        U <- seq(0,1,by = 0.01)
        z = outer(U,U,outfun,item = item,mod = mod, knots = knots, basis = basis)
        df_names <- df_item %>% filter(!is.na(Prob)) %>% distinct(attribute) %>% unlist() %>% as.character()
        df_contour = data.frame(expand.grid(U,U),c(z)); names(df_contour) = c(df_names,"IRF")
        df_legend <- data.frame(x = 1, y = 1, value = seq(0, 1, length.out = 50)) ; names(df_legend) = c(df_names,"IRF")
        df_legend <- df_legend %>% mutate_all(round,3)

        gf_c1 <-
            ggplot(df_contour, aes(x=get(names(df_contour)[1]), y = get(names(df_contour)[2]), z = IRF)) +
            geom_contour_filled(bins = 50, show.legend = F) +
            geom_contour(color = "gray",bins = 50, alpha = .5) +
            scale_fill_grey(start = 1, end = 0) +
            xlab(names(df_contour)[1]) +
            ylab(names(df_contour)[2]) +
            theme_classic() +
            scale_x_continuous(breaks=c(0, .5, 1)) +
            scale_y_continuous(breaks=c(0, .5, 1)) +
            theme(plot.title = element_text(margin = margin(t = 0, r = 0, b = 5, l = 0), size = 15),
                  plot.subtitle = element_text(margin = margin(t = 0, r = 0, b = 10, l = 0), size = 13),
                  axis.title.y = element_text(margin = margin(t = 0, r = 7, b = 0, l = 0), size = 13),
                  axis.title.x = element_text(margin = margin(t = 12, r = 0, b = 0, l = 0), size = 13),
                  axis.title =   element_text(margin = margin(t = 0, r = 0, b = 10, l = 0)),
                  axis.text.x = element_text(size = 11),
                  axis.text.y = element_text(size = 11),
                  plot.margin = margin(t = 18, r = 2, b = 8, l = 5)) +
            geom_point(data = df_legend, aes(x=get(names(df_contour)[1]), y = get(names(df_contour)[2]), color = IRF), size = -1) +
            scale_color_gradient(low = "white", high = "black",
                                 name = "IRF\n",
                                 guide = guide_colorbar(barwidth = 1, barheight = 8, title.position = "top",
                                                        theme = theme(legend.text.position = "left")))

    } else {
        gf_c1 <- ggplot() + theme_void()
    }

    grid.arrange(gf_item, gf_c1, ncol = 2, widths = c(2, 1))
}

# Figure 2: Estimated weights, monotone functions, and IRF surface under the GaPM-CDM, selected items 1, 3, and 12. ECPE dataset
# ~~~~~~~~~~
K1 = c(.025,.05,seq(.1,.9,by = .1),.95,.975)
gf_i1 <- plot_pmCDM(item = 1, mod = mod_GaPMCDM, knots = K1)  # save as 930 widht x 250 height
gf_i3 <- plot_pmCDM(item = 3, mod = mod_GaPMCDM, knots = K1)  # save as 930 wight x 250 height
gf_i12 <- plot_pmCDM(item = 12, mod = mod_GaPMCDM, knots = K1)  # save as 930 wight x 250 height

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ---- Plots for EAP factor scores ----
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# U = as.data.frame(rbind(mod_aPMCDM$U)) # Uncomment for mod_aPMCDM
U = as.data.frame(rbind(mod_GaPMCDM$U))
names(U) = c("Morph.", "Cohes.", "Lexic.")
U$model = factor(rep(c("ad"),each= nrow(mod_GaPMCDM$U)), levels = c("ad"))

gf_MC <-
    ggplot(U, aes(x=Morph., y = Cohes.)) +
    geom_point(aes(colour=model, shape = model), alpha = 0.5) +
    scale_color_manual(values = c("ga" = "gray20", "ad" = "gray20")) +
    theme_bw() +
    scale_x_continuous(breaks=c(0, .5, 1), limits = c(0,1)) +
    scale_y_continuous(breaks=c(0, .5, 1), limits = c(0,1)) +
    theme(plot.title = element_text(margin = margin(t = 0, r = 0, b = 5, l = 0), size = 15),
          plot.subtitle = element_text(margin = margin(t = 0, r = 0, b = 10, l = 0), size = 13),
          axis.title.y = element_text(margin = margin(t = 0, r = 12, b = 0, l = 0), size = 13),
          axis.title.x = element_text(margin = margin(t = 12, r = 0, b = 0, l = 0), size = 13),
          axis.title =   element_text(margin = margin(t = 0, r = 0, b = 10, l = 0)),
          axis.text.x = element_text(size = 11),
          axis.text.y = element_text(size = 11),
          plot.margin = margin(t = 18, r = 5, b = 8, l = 2),
          panel.spacing = unit(1, "lines"),
          strip.background = element_rect(fill="white"),
          legend.position="none") +
    ylab(TeX(r"(Cohes.)")) +
    xlab(TeX(r"(Morph.)"))

gf_CL <-
    ggplot(U, aes(x=Cohes., y = Lexic.)) +
    geom_point(aes(colour=model, shape = model), alpha = 0.5) +
    scale_color_manual(values = c("ga" = "gray20", "ad" = "gray20")) +
    theme_bw() +
    scale_x_continuous(breaks=c(0, .5, 1), limits = c(0,1)) +
    scale_y_continuous(breaks=c(0, .5, 1), limits = c(0,1)) +
    theme(plot.title = element_text(margin = margin(t = 0, r = 0, b = 5, l = 0), size = 15),
          plot.subtitle = element_text(margin = margin(t = 0, r = 0, b = 10, l = 0), size = 13),
          axis.title.y = element_text(margin = margin(t = 0, r = 12, b = 0, l = 0), size = 13),
          axis.title.x = element_text(margin = margin(t = 12, r = 0, b = 0, l = 0), size = 13),
          axis.title =   element_text(margin = margin(t = 0, r = 0, b = 10, l = 0)),
          axis.text.x = element_text(size = 11),
          axis.text.y = element_text(size = 11),
          plot.margin = margin(t = 18, r = 5, b = 8, l = 2),
          panel.spacing = unit(1, "lines"),
          strip.background = element_rect(fill="white"),
          legend.position="none") +
    ylab(TeX(r"(Lexic.)")) +
    xlab(TeX(r"(Cohes.)"))

gf_LM <-
    ggplot(U, aes(y=Morph., x = Lexic.)) +
    geom_point(aes(colour=model, shape = model), alpha = 0.75) +
    scale_color_manual(values = c("ga" = "gray20", "ad" = "gray20")) +
    theme_bw() +
    scale_x_continuous(breaks=c(0, .5, 1), limits = c(0,1)) +
    scale_y_continuous(breaks=c(0, .5, 1), limits = c(0,1)) +
    theme(plot.title = element_text(margin = margin(t = 0, r = 0, b = 5, l = 0), size = 15),
          plot.subtitle = element_text(margin = margin(t = 0, r = 0, b = 10, l = 0), size = 13),
          axis.title.y = element_text(margin = margin(t = 0, r = 12, b = 0, l = 0), size = 13),
          axis.title.x = element_text(margin = margin(t = 12, r = 0, b = 0, l = 0), size = 13),
          axis.title =   element_text(margin = margin(t = 0, r = 0, b = 10, l = 0)),
          axis.text.x = element_text(size = 11),
          axis.text.y = element_text(size = 11),
          plot.margin = margin(t = 18, r = 5, b = 8, l = 2),
          panel.spacing = unit(1, "lines"),
          strip.background = element_rect(fill="white"),
          legend.position="none") +
    ylab(TeX(r"(Morph.)")) +
    xlab(TeX(r"(Lexic.)"))

# Figure A2: Estimated EAP factor scores. ECPE data
gf_EAP = grid.arrange(gf_MC, gf_CL, gf_LM, ncol = 3)
