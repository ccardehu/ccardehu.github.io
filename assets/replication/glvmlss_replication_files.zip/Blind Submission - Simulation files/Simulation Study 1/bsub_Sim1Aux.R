simCppE1 <- function(nsim = 1000, n = 200, p = 5){
  
  set.seed(1234)
  
  faml = rep("beta",p)
  lc <- array(NA,dim = c(p,2,2))
  lc[,1,1] <- runif(length(lc[,1,1]), -1.5, 1.5)
  lc[,2,1] <- runif(length(lc[,2,1]), 0.5, 1.0)
  lc[,2,1] <- lc[,2,1] * sample(c(-1,1), p ,replace = T)
  lc[,,2] <- runif(length(lc[,1,2]), 0.1, 0.5)
  lc[,2,2] <- lc[,2,2] * sample(c(-1,1), p ,replace = T)
  if(lc[1,2,1] < 0) lc[,2,1] <- -lc[,2,1]
  if(lc[1,2,2] < 0) lc[,2,2] <- -lc[,2,2]
  
  bc = lc
  
  ncores  = parallel::detectCores()
  cl <- parallel::makeCluster(ncores)
  
  on.exit(parallel::stopCluster(cl))
  
  parallel::clusterExport(cl, ls(.GlobalEnv))
  doSNOW::registerDoSNOW(cl)
  
  progress <- function(a) setTxtProgressBar(txtProgressBar(max = nsim, style = 3), a)
  opts <- list(progress = progress)
  
  bcS <- bc

  cat(paste0("\n Simulation E1: p = ",p,", n = ",n,"\n"))
  
  estimates <-
    foreach::foreach(i = 1:nsim,
                     .combine = "rbind",
                     .options.snow = opts,
                     .packages = c("numDeriv","glvmlss")) %dopar% {
                       
                       tryCatch({
                         AA <- glvmlss_sim(n = n, family = faml, mu.eq = ~ Z1, sg.eq = ~ Z1, "start.b" = bc)
                         t0 <- Sys.time()
                         AB <- glvmlss(data = AA$Y,family = faml,mu.eq = ~ Z1, sg.eq = ~ Z1,
                                       "DM.maxit" = 500, "nQP" = 100, "Fisher" = T, "verbose" = F,
                                       "corLV" = F, "tolerance" = sqrt(.Machine$double.eps), "start.b" = bcS)
                         t1 <- Sys.time()
                         tout <- difftime(t1,t0,units = "mins")
                         return(c(c(AA$b)[c(AA$b) != 0], c(AB$b)[c(AB$b) != 0], c(AB$seb)[c(AB$seb)!=0], tout))
                       },
                       error = function(e) { return(NA) }  )
                     }
  saveRDS(estimates,paste0("Simulation Study 1/Results/simCpp_S1_p",p,"n",n,".rds"))
}

outCppE1 <- function(n = 200, p = 5, plot = F){
  
  A <- readRDS(paste0("Simulation Study 1/Results/simCpp_S1_p",p,"n",n,".rds"))
  
  co <- complete.cases(A)
  
  M1 <- A[co,1:(p*4)]
  M2 <- A[co,((p*4)+1):(2*(p*4))]
  M3 <- A[co,((2*p*4)+1):(3*(p*4))]
  ti <- A[co,ncol(A)]
  
  MSEm0 <- mean((M1[,1:p] - M2[,1:p])^2)
  MSEm1 <- mean((M1[,(p+1):(2*p)] - M2[,(p+1):(2*p)])^2)
  MSEs0 <- mean((M1[,(2*p+1):(3*p)] - M2[,(2*p+1):(3*p)])^2)
  MSEs1 <- mean((M1[,(3*p+1):(4*p)] - M2[,(3*p+1):(4*p)])^2)
  
  ABBm0 <- mean(abs(colMeans(M1[,1:p] - M2[,1:p])))
  ABBm1 <- mean(abs(colMeans(M1[,(p+1):(2*p)] - M2[,(p+1):(2*p)])))
  ABBs0 <- mean(abs(colMeans(M1[,(2*p+1):(3*p)] - M2[,(2*p+1):(3*p)])))
  ABBs1 <- mean(abs(colMeans(M1[,(3*p+1):(4*p)] - M2[,(3*p+1):(4*p)])))
  
  ACOm0 <- mean((M1[,1:p] > M2[,1:p] - qnorm(0.975)*M3[,1:p]) & (M1[,1:p] < M2[,1:p] + qnorm(0.975)*M3[,1:p]))
  ACOm1 <- mean((M1[,(p+1):(2*p)] > M2[,(p+1):(2*p)] - qnorm(0.975)*M3[,(p+1):(2*p)]) & (M1[,(p+1):(2*p)] < M2[,(p+1):(2*p)] + qnorm(0.975)*M3[,(p+1):(2*p)]))
  ACOs0 <- mean((M1[,(2*p+1):(3*p)] > M2[,(2*p+1):(3*p)] - qnorm(0.975)*M3[,(2*p+1):(3*p)]) & (M1[,(2*p+1):(3*p)] < M2[,(2*p+1):(3*p)] + qnorm(0.975)*M3[,(2*p+1):(3*p)]))
  ACOs1 <- mean((M1[,(3*p+1):(4*p)] > M2[,(3*p+1):(4*p)] - qnorm(0.975)*M3[,(3*p+1):(4*p)]) & (M1[,(3*p+1):(4*p)] < M2[,(3*p+1):(4*p)] + qnorm(0.975)*M3[,(3*p+1):(4*p)]))
  
  COMPT <- mean(ti)
  
  if(plot){
    boxplot(M2, main = paste0("Simulation Study I (n: ", n, ", p: ", p,")"))
    points(colMeans(M1), col = 2, pch = 16)
    abline(v = c((p+0.5)+(0:2)*p), lty = 3, lwd = 2, col = 3)
    plot(apply(M2,2,sd), colMeans(M3), main = paste0("Simulation Study I (n: ", n, ", p: ", p,")"),
         xlab = "Empirical SEs", ylab = "Estimated SEs")
    abline(a = 0, b = 1, lty = 3, lwd = 2)
  }
  
  return(c(p,n,MSEm0, MSEm1, MSEs0, MSEs1, ABBm0, ABBm1, ABBs0, ABBs1,
           ACOm0, ACOm1, ACOs0, ACOs1, COMPT))
}
