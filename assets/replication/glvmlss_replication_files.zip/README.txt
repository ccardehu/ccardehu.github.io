
Description for the auxiliary and replication files of the paper
"Generalized Latent Variable Models for Location, Scale, and Shape parameters"

*** R package: One (1) file "glvmlss_0.0.1.tar.gz".
    This the source file of the glvmlss R package. 
    Install in R via "install.packages("glvmlss_0.0.1.tar.gz", type = "source", repos = NULL)".
    Please download and save this file in your working directory.

*** Folder: "Blind Submission - Auxiliary files"
    This folder contains four (4) files:
    - "bsub_Results_ANES2020.Rdata"
       This file contains the results for empirical application # 1 (ANES 2020 dataset)
       Please download and save this file in your working directory.
    - "bsub_Results_PISA2018.Rdata"
       This file contains the results for empirical application # 2 (PISA 2018 dataset)
       Please download and save this file in your working directory.
    - "plotAuxE1.R"
       This file contains auxiliary plotting functions for empirical application # 1 (ANES 2020 dataset)
       Please download and save this file in your working directory.
    - "plotAuxE2.R"
       This file contains auxiliary plotting functions for empirical application # 2 (PISA 2018 dataset)
       Please download and save this file in your working directory.

*** Folder: "Blind Submission - Empirical Applications"
    This folder contains two (2) files:
    - "bsub_ANES2020.R"
       This file contains replication code for empirical application # 1 (ANES 2020 dataset)
       Please download and save this file in your working directory.
       NOTE: This file loads the "glvmlss" R package and sources file "plotAuxE1.R" to produce plots.
    - "bsub_PISA2018.R"
       This file contains replication code for empirical application # 2 (PISA 2018 dataset)
       Please download and save this file in your working directory.
       NOTE: This file loads the "glvmlss" R package and sources file "plotAuxE2.R" to produce plots.

*** Folder: "Blind Submission - Simulation files"
    This folder contains one (1) file and two (2) sub-folders:
    - File "bsub_SimResults.R"
      This file contains code to replicate result tables from Section 4.

    ** Sub-folder "Simulation Study 1":
       This subfolder contains one (1) file and one (1) sub-sub-folder:
       - File "bsub_Sim1Aux.R"
         This file contains auxiliary functions for parallelized simulation and results processing in Simulation Study 1.
         This file calls .rds files from sub-sub-folder "Simulation Study 1/Results".
       * Sub-sub-folder "Simulation Study 1/Results":
         This subsubfolder contains .rds files containing results for Simulation Study 1 (by sample size and test size).


    ** Sub-folder "Simulation Study 2":
       Simulation Study 2 was conducted in a HPC. The bash files are included, which allow for parallelization.
       This subfolder contains one (1) file and two (2) sub-sub-folders:
       - File "bsub_Sim2Aux.R"
         This file contains auxiliary functions for results processing in Simulation Study 2.
         This file calls .rds files from sub-sub-folder "Simulation Study 1/Results".
       * Sub-sub-folder "Simulation Study 2/Results":
         This subsubfolder contains .rds files containing results for Simulation Study 2 (by sample size).
       * Sub-sub-folder "Simulation Study 2/HPC files":
         This subsubsubfolder contains four (4) files.
         - "bsub_Sim2.sbatch"
            This is a bash file containing the instructions to set the job in the HPC.
         - "bsub_Sim2n500.R"
         - "bsub_Sim2n1000.R"
         - "bsub_Sim2n3000.R"
            These files contain the code for simulation 2 (sample sizes n = 500, 1000, 3000).
            These are called from "bsub_Sim2.sbatch" (need to update for every sample size).